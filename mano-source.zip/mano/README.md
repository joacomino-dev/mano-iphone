# CocoWash — recuerdos que se quedan

Una app de iPhone para revisar Fotos mediante una mano de cartas. Interfaz verde petróleo, papel y sellos de tinta; sin cuenta propia, anuncios, suscripciones ni API de reconocimiento de pago.

La bienvenida muestra fotos flotantes y «Iniciar sesión». Cada sesión mezcla al azar fotos, vídeos y Live Photos; cuando un elemento pertenece a un grupo visual analizado, aparece automáticamente un bundle de polaroids. La foto principal queda centrada y recta; tocarla o pulsar Siguiente la pasa al final. Puedes seleccionar varias girando la pila o elegir todas. Los filtros permiten cambiar el orden.

El nombre visible y el icono son CocoWash; el identificador interno y las claves de datos se conservan para actualizar la instalación existente.

## Uso

- Derecha conserva; izquierda añade a una cola pendiente; arriba marca como favorita.
- Tocar el centro de la primera carta la pasa al fondo. Tocar su control de selección permite elegir varias y decidir juntas.
- Mantener pulsado inspecciona la foto sin sello. Soltar vuelve a la mano.
- Terminar abre la revisión. Mantener pulsado un descarte y arrastrarlo a la derecha lo recupera. También hay un botón accesible Recuperar.
- Finalizar sesión vuelve a la bienvenida y conserva los descartes pendientes; no los borra.
- El borrado real solo ocurre después de la revisión y la confirmación de Fotos. Favoritos y fotos ocultas se vuelven a proteger antes de borrar.
- Álbum añade las seleccionadas a un álbum real existente. No las saca de la biblioteca general.
- Vídeos y Live Photos tienen reproducción nativa. Las fotos RAW/HEIF y otros formatos admitidos por Fotos usan su vista previa sin convertir ni reemplazar el original.

## Sellos

Blanco, rojo, verde, negro, azul, morado, naranja y dorado. Conservar de nuevo incrementa el nivel; aparecer por sí solo no lo incrementa. Descanso por nivel: 7, 14, 30, 60, 120, 240 y 365 días; dorado solo se revisa manualmente. Las fotos sin sello tienen prioridad. El filtro por sello permite revisar un nivel aunque todavía esté descansando.

Los sellos son metadatos locales y capas visuales; jamás se imprimen sobre el original. Deshacer restaura el nivel y la fecha anteriores.

## Privacidad y límites

El análisis utiliza Apple Vision dentro del iPhone. Compara vistas previas de fotos, Live Photos y portadas de vídeo; no analiza el vídeo completo. Las agrupaciones son sugerencias de parecido visual, no detección infalible de duplicados. La primera indexación empieza tras autorizar Fotos y se puede repetir desde Sellos. Los resultados se guardan localmente.

El análisis inicial solo usa vistas previas disponibles localmente y comunica las que no puede analizar. Abrir una foto o reproducirla puede descargar contenido desde tu iCloud; no se envía a ningún servidor de Mano. Ocultas y favoritas no se incluyen. Con acceso limitado solo se revisan los elementos autorizados.

La cola, sellos e historial se guardan en el almacenamiento de la app y sobreviven a cierres normales. No desinstales la app para renovar la firma: al desinstalar puedes perder esos metadatos. La biblioteca original sigue perteneciendo a Fotos. El borrado con Fotos en iCloud se sincroniza con otros dispositivos.

## Desarrollo

Requisitos: Node 22+, npm. La vista previa conserva el runtime móvil de Product Design; la app instalada usa una entrada propia sin marco ni teclado ficticios.

```sh
npm ci
npm run dev -- --host 127.0.0.1 --port 4173
npm test
npm run check:runtime
npm run build
npm run sync:ios
```

`src/ManoApp.tsx` contiene la interfaz compartida; `src/domain.ts` la cola y los sellos; `ios/App/App/PhotoLibrary.swift` el puente PhotoKit/Vision. Las fotos incluidas en la demostración son generadas; el navegador nunca accede a tus originales ni realiza borrados reales.

El análisis se puede detener desde Sellos. Una huella visual rápida limita a 64 los candidatos comparados con Vision por imagen; los grupos siguen siendo sugerencias que debes revisar. Un análisis parcial de iCloud no se marca como terminado: Actualizar o volver a abrir permite intentarlo otra vez. La biblioteca y sus fechas de modificación invalidan la marca de análisis completado cuando cambian.

## Compilación gratuita e instalación

El workflow del repositorio usa únicamente runners estándar y se bloquea si el repositorio es privado. Compila el dispositivo iPhone sin firma y produce `Mano-AltStore/Mano-unsigned.ipa` como artefacto. No necesita certificados, contraseña de Apple, suscripción Developer ni secretos en GitHub. El job inicial puede expandir un `mano-source.zip` subido desde navegador y dejar el código normal en el repositorio; después ya no modifica fuentes.

1. Descargar el artefacto de una ejecución verde de Actions y extraer el `.ipa`.
2. Conectar el iPhone al PC y abrir iLoader con la misma cuenta de Apple usada para la instalación existente. Cualquier autenticación, confianza del dispositivo o Modo Desarrollador se completa personalmente.
3. Elegir el iPhone y usar **Import IPA** para firmar e instalar el archivo. Abrir CocoWash, permitir acceso completo a Fotos en la bienvenida y pulsar **Iniciar sesión** para revisar todo el carrete.
4. Renovar la firma antes de siete días mediante **Import IPA**, con la misma cuenta y el identificador `work.joaquin.mano`. Actualizar la instalación existente; no desinstalarla.

La instalación personal elegida usa iLoader; no requiere instalar AltStore, SideStore ni una VPN.

La compilación no demuestra funcionamiento en un iPhone real. La verificación física pendiente comprueba permisos, miniaturas, iCloud y reproducción sin confirmar ningún borrado. Los flujos de descarte y recuperación se prueban con las imágenes generadas de la demostración.

## Precarga y vídeo (0.3)

Antes de empezar se preparan los próximos10 elementos, siguiendo el orden real y los bundles, con progreso y cancelación. La ventana se renueva al avanzar. Dos preparaciones simultáneas; las miniaturas quedan listas para mostrarse y los vídeos se descargan a una caché local temporal. Reproducir abre el vídeo dentro de la tarjeta; pantalla completa queda como alternativa explícita. Los vídeos demasiado grandes o no disponibles permiten reintentar o usar la reproducción nativa. Los originales no se alteran. El tamaño de caché es limitado y sus archivos en uso se protegen contra expulsión.

## CocoWash0.4

Sesiones guardadas con continuidad exacta y Regresar de10 pasos. Filtros por24h/7d/30d o calendario inclusivo, Modo Geek local y creación de álbumes en Fotos. Mantener pulsado amplía; arrastrar al gancho ancla; pellizcar permite zoom, tocar fuera o Cerrar vuelve a las cartas. Cabecera compacta, polaroids adaptadas al archivo y nueva identidad vectorial. Sin cambiar bundle ni claves anteriores.

La revisión final tiene Eliminar/Deshacer todo primero. Eliminar solicita solo la confirmación de Apple; cancelar conserva la cola. Finalizar y guardar pendientes no borra archivos. El historial rápido registra decisiones de conservar/eliminar/favorita; añadir a álbum no se revierte con Regresar. Datos EXIF solo cuando locales; no se descargan originales para inspección.
